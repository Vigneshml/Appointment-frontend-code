
import {Patient} from "../model/patient";


export class Appointment {
    constructor( public appID: number,
    public drID: number,
    public slotID: number,
    public complaint: string,
    public appDate : string,
    public patient : Patient ){

    }
  }