

export class Patient {
  constructor(
  public patientID: number,
  public firstName: string,
  public lastName: string,
  public phoneNumber: string){

  }
}