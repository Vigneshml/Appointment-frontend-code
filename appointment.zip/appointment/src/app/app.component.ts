import { Component , OnInit} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {ModalService} from './_modal';
import {Appointment} from './model/appointment';
import {Patient} from './model/patient';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'appointment';
  dateSelected : Date;
  dateSelectedForAppointment : Date;
  name : string;
  ego: string;
  show: boolean = false;

  appointment : Appointment = new Appointment(0,10,0,"","", new Patient(0,"","",""));
  
    restItems: any;
    patients : Patient[];
    restItemsUrl = 'http://localhost:8082/appointment/date/';
  
    constructor(private http: HttpClient, private modalService: ModalService) {
      
    }
  
    ngOnInit() {
      
      this.getPatients();
      this.getRestItems();
    }
  
    // Read all REST Items
    getRestItems(): void {
      this.restItemsServiceGetRestItems()
        .subscribe(
          restItems => {
            this.restItems = restItems;
            console.log(this.restItems);
          }
        )
    }
  
    // Rest Items Service: Read all REST Items
    restItemsServiceGetRestItems() {
      return this.http
        .get<any[]>(this.restItemsUrl+ this.dateSelected)
        .pipe(map(data => data));
    }

    getPatients(): void {
      this.restGetPatients()
        .subscribe(
          patientData => {
            this.patients = patientData;
            console.log(this.patients);
          }
        )
    }

    restGetPatients(){
      return this.http
        .get<Patient[]>("http://localhost:8082/patients")
        .pipe(map(data => data));
    }

    postPatient(): void {
      this.restPostAppointment()
        .subscribe(
          appointmentData => {
            console.log(appointmentData);
          }
        )
    }

    
    restPostAppointment(){
      return this.http
        .post("http://localhost:8082/appointment", this.appointment)
        .pipe(map(data => data));
    }
    
   openModal(id : string){
     this.show = true;
     this.appointment.patient.patientID = 0;
     this.appointment.slotID =0;
     this.appointment.complaint = "";
    }

   saveAppointment(){
     this.show = false;
     this.appointment.appDate = this.dateSelectedForAppointment.toString();
     console.log(JSON.stringify(this.appointment));
     console.log("complaint is..."+ this.appointment.complaint);
     console.log("date id is..."+ this.dateSelectedForAppointment);
     this.postPatient();
     this.getRestItems();
     //console.log("patient is..."+ this.patients);
      //this.modalService.close(id);
   }

}



